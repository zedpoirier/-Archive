﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 UnityEngine.Quaternion UnityEngine.XR.Tango.PoseData::get_rotation()
extern void PoseData_get_rotation_m8784EAC91FE13E8909E972A0AD9B9A9B9CAA2981_AdjustorThunk ();
// 0x00000002 UnityEngine.Vector3 UnityEngine.XR.Tango.PoseData::get_position()
extern void PoseData_get_position_m356B0853C5A393D0748E95FCBEF3BFDA9AC46D9B_AdjustorThunk ();
// 0x00000003 System.Boolean UnityEngine.XR.Tango.TangoInputTracking::Internal_TryGetPoseAtTime(UnityEngine.XR.Tango.PoseData&)
extern void TangoInputTracking_Internal_TryGetPoseAtTime_m6324D495343239E4BBEDF51EB99B056BC4BB260F ();
// 0x00000004 System.Boolean UnityEngine.XR.Tango.TangoInputTracking::TryGetPoseAtTime(UnityEngine.XR.Tango.PoseData&)
extern void TangoInputTracking_TryGetPoseAtTime_m8AA6B8CEADE806F981A62E2928425265987F1C3F ();
static Il2CppMethodPointer s_methodPointers[4] = 
{
	PoseData_get_rotation_m8784EAC91FE13E8909E972A0AD9B9A9B9CAA2981_AdjustorThunk,
	PoseData_get_position_m356B0853C5A393D0748E95FCBEF3BFDA9AC46D9B_AdjustorThunk,
	TangoInputTracking_Internal_TryGetPoseAtTime_m6324D495343239E4BBEDF51EB99B056BC4BB260F,
	TangoInputTracking_TryGetPoseAtTime_m8AA6B8CEADE806F981A62E2928425265987F1C3F,
};
static const int32_t s_InvokerIndices[4] = 
{
	1328,
	1129,
	344,
	344,
};
extern const Il2CppCodeGenModule g_UnityEngine_ARModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_ARModuleCodeGenModule = 
{
	"UnityEngine.ARModule.dll",
	4,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
