﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void System.Xml.XmlReader::.cctor()
extern void XmlReader__cctor_m3EF2489C81E4EEF249A34242FC130A861972991E ();
static Il2CppMethodPointer s_methodPointers[1] = 
{
	XmlReader__cctor_m3EF2489C81E4EEF249A34242FC130A861972991E,
};
static const int32_t s_InvokerIndices[1] = 
{
	3,
};
extern const Il2CppCodeGenModule g_System_XmlCodeGenModule;
const Il2CppCodeGenModule g_System_XmlCodeGenModule = 
{
	"System.Xml.dll",
	1,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
